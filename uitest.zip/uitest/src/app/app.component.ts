import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'uitest2';
  showsignup : boolean = false;
  showlogin : boolean = false;

  imageUrl="https://www.gettyimages.ie/gi-resources/images/Homepage/Hero/UK/CMS_Creative_164657191_Kingfisher.jpg"
  getUrl()
{
  return "url('assets/images/background2.png')";
}
constructor(){
  this.showsignup = false;
  this.showlogin = false;
}

signupclick(){
  this.showsignup = true;
}

loginclick(){
  this.showlogin = true;
}
}
